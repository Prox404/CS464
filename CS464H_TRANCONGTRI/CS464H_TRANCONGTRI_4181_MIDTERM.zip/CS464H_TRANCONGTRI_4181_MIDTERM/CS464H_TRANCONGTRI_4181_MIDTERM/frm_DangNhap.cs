﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CS464H_TRANCONGTRI_4181_MIDTERM
{
	public partial class frm_DangNhap : Form
	{
		private int soLanNhap = 0;
		Connection conn = new Connection();

		public frm_DangNhap()
		{
			InitializeComponent();
		}

		private void btn_DangNhap_Click(object sender, EventArgs e)
		{
			String taiKhoan = txt_TaiKhoan.Text;
			String matKhau = txt_MatKhau.Text;

			try
			{
				conn.Connect();
				String sql = "SELECT * FROM THONGTINTAIKHOAN WHERE TaiKhoan = '" + taiKhoan + "' AND MatKhau = '" + matKhau + "'";
				DataTable dt = conn.getData(sql);
				if (dt != null && dt.Rows.Count > 0)
				{
					MessageBox.Show("Đăng nhập thành công");
					this.Hide();
					frm_DanhMucHang f = new frm_DanhMucHang();
					f.ShowDialog();
					this.Close();
				}
				else
				{
					soLanNhap++;
					if (soLanNhap == 3)
					{
						MessageBox.Show("Bạn đã nhập sai 3 lần");
						this.Close();
					}
					MessageBox.Show("Bạn đã nhập sai " + soLanNhap + " lần!");
				}
				conn.close();
			}
			catch (System.Exception)
			{
				throw new System.Exception("Lỗi kết nối");
			}
		}

		private void btn_Thoat_Click(object sender, EventArgs e)
		{
			if (DialogResult.Yes == MessageBox.Show(("Bạn muốn đóng chứ ?"), "Đóng", MessageBoxButtons.YesNo)){
				this.Close();
			}
		}
	}
}
