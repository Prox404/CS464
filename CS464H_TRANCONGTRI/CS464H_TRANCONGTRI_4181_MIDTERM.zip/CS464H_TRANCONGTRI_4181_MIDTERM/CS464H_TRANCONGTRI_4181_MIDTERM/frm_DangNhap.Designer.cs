﻿namespace CS464H_TRANCONGTRI_4181_MIDTERM
{
	partial class frm_DangNhap
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btn_DangNhap = new System.Windows.Forms.Button();
			this.txt_MatKhau = new System.Windows.Forms.TextBox();
			this.lbl_MatKhau = new System.Windows.Forms.Label();
			this.txt_TaiKhoan = new System.Windows.Forms.TextBox();
			this.lbl_TaiKhoan = new System.Windows.Forms.Label();
			this.btn_Thoat = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// btn_DangNhap
			// 
			this.btn_DangNhap.Location = new System.Drawing.Point(191, 198);
			this.btn_DangNhap.Name = "btn_DangNhap";
			this.btn_DangNhap.Size = new System.Drawing.Size(75, 23);
			this.btn_DangNhap.TabIndex = 9;
			this.btn_DangNhap.Text = "Login";
			this.btn_DangNhap.UseVisualStyleBackColor = true;
			this.btn_DangNhap.Click += new System.EventHandler(this.btn_DangNhap_Click);
			// 
			// txt_MatKhau
			// 
			this.txt_MatKhau.Location = new System.Drawing.Point(139, 154);
			this.txt_MatKhau.Name = "txt_MatKhau";
			this.txt_MatKhau.Size = new System.Drawing.Size(208, 20);
			this.txt_MatKhau.TabIndex = 8;
			// 
			// lbl_MatKhau
			// 
			this.lbl_MatKhau.AutoSize = true;
			this.lbl_MatKhau.Location = new System.Drawing.Point(74, 154);
			this.lbl_MatKhau.Name = "lbl_MatKhau";
			this.lbl_MatKhau.Size = new System.Drawing.Size(56, 13);
			this.lbl_MatKhau.TabIndex = 7;
			this.lbl_MatKhau.Text = "Password:";
			// 
			// txt_TaiKhoan
			// 
			this.txt_TaiKhoan.Location = new System.Drawing.Point(139, 116);
			this.txt_TaiKhoan.Name = "txt_TaiKhoan";
			this.txt_TaiKhoan.Size = new System.Drawing.Size(208, 20);
			this.txt_TaiKhoan.TabIndex = 6;
			// 
			// lbl_TaiKhoan
			// 
			this.lbl_TaiKhoan.AutoSize = true;
			this.lbl_TaiKhoan.Location = new System.Drawing.Point(74, 116);
			this.lbl_TaiKhoan.Name = "lbl_TaiKhoan";
			this.lbl_TaiKhoan.Size = new System.Drawing.Size(58, 13);
			this.lbl_TaiKhoan.TabIndex = 5;
			this.lbl_TaiKhoan.Text = "Username:";
			// 
			// btn_Thoat
			// 
			this.btn_Thoat.Location = new System.Drawing.Point(272, 198);
			this.btn_Thoat.Name = "btn_Thoat";
			this.btn_Thoat.Size = new System.Drawing.Size(75, 23);
			this.btn_Thoat.TabIndex = 10;
			this.btn_Thoat.Text = "Exit";
			this.btn_Thoat.UseVisualStyleBackColor = true;
			this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Coral;
			this.label1.Location = new System.Drawing.Point(137, 52);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(129, 25);
			this.label1.TabIndex = 11;
			this.label1.Text = "Dang Nhap";
			// 
			// frm_DangNhap
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(426, 274);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btn_Thoat);
			this.Controls.Add(this.btn_DangNhap);
			this.Controls.Add(this.txt_MatKhau);
			this.Controls.Add(this.lbl_MatKhau);
			this.Controls.Add(this.txt_TaiKhoan);
			this.Controls.Add(this.lbl_TaiKhoan);
			this.Name = "frm_DangNhap";
			this.Text = "frm_DangNhap";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btn_DangNhap;
		private System.Windows.Forms.TextBox txt_MatKhau;
		private System.Windows.Forms.Label lbl_MatKhau;
		private System.Windows.Forms.TextBox txt_TaiKhoan;
		private System.Windows.Forms.Label lbl_TaiKhoan;
		private System.Windows.Forms.Button btn_Thoat;
		private System.Windows.Forms.Label label1;
	}
}