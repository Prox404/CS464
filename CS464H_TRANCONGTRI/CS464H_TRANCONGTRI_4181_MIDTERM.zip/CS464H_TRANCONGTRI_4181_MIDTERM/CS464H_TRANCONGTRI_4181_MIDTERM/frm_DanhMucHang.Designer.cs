﻿namespace CS464H_TRANCONGTRI_4181_MIDTERM
{
	partial class frm_DanhMucHang
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label1 = new System.Windows.Forms.Label();
			this.txt_MaHang = new System.Windows.Forms.TextBox();
			this.txt_TenHang = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.cb_NhaCungCap = new System.Windows.Forms.ComboBox();
			this.cb_DonViTinh = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.btn_Xoa = new System.Windows.Forms.Button();
			this.btn_Sua = new System.Windows.Forms.Button();
			this.btn_Them = new System.Windows.Forms.Button();
			this.btn_Thoat = new System.Windows.Forms.Button();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.thêmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.sửaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.xoáToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(44, 66);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(51, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Mã Hàng";
			// 
			// txt_MaHang
			// 
			this.txt_MaHang.Location = new System.Drawing.Point(118, 63);
			this.txt_MaHang.Name = "txt_MaHang";
			this.txt_MaHang.Size = new System.Drawing.Size(146, 20);
			this.txt_MaHang.TabIndex = 1;
			// 
			// txt_TenHang
			// 
			this.txt_TenHang.Location = new System.Drawing.Point(118, 103);
			this.txt_TenHang.Name = "txt_TenHang";
			this.txt_TenHang.Size = new System.Drawing.Size(146, 20);
			this.txt_TenHang.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(44, 106);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(55, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Tên Hàng";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(315, 66);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(99, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Tên Nhà Cung Cấp";
			// 
			// cb_NhaCungCap
			// 
			this.cb_NhaCungCap.FormattingEnabled = true;
			this.cb_NhaCungCap.Location = new System.Drawing.Point(420, 63);
			this.cb_NhaCungCap.Name = "cb_NhaCungCap";
			this.cb_NhaCungCap.Size = new System.Drawing.Size(121, 21);
			this.cb_NhaCungCap.TabIndex = 5;
			// 
			// cb_DonViTinh
			// 
			this.cb_DonViTinh.FormattingEnabled = true;
			this.cb_DonViTinh.Items.AddRange(new object[] {
            "Tấn",
            "Tạ",
            "Yến",
            "Kilogram"});
			this.cb_DonViTinh.Location = new System.Drawing.Point(647, 63);
			this.cb_DonViTinh.Name = "cb_DonViTinh";
			this.cb_DonViTinh.Size = new System.Drawing.Size(121, 21);
			this.cb_DonViTinh.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(581, 70);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(60, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Đơn vị tính";
			// 
			// dataGridView1
			// 
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(47, 244);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataGridView1.Size = new System.Drawing.Size(721, 176);
			this.dataGridView1.TabIndex = 8;
			this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
			// 
			// btn_Xoa
			// 
			this.btn_Xoa.Location = new System.Drawing.Point(269, 173);
			this.btn_Xoa.Name = "btn_Xoa";
			this.btn_Xoa.Size = new System.Drawing.Size(75, 23);
			this.btn_Xoa.TabIndex = 72;
			this.btn_Xoa.Text = "Xoa";
			this.btn_Xoa.UseVisualStyleBackColor = true;
			this.btn_Xoa.Click += new System.EventHandler(this.btn_Xoa_Click);
			// 
			// btn_Sua
			// 
			this.btn_Sua.Location = new System.Drawing.Point(161, 174);
			this.btn_Sua.Name = "btn_Sua";
			this.btn_Sua.Size = new System.Drawing.Size(75, 23);
			this.btn_Sua.TabIndex = 71;
			this.btn_Sua.Text = "Sua";
			this.btn_Sua.UseVisualStyleBackColor = true;
			this.btn_Sua.Click += new System.EventHandler(this.btn_Sua_Click);
			// 
			// btn_Them
			// 
			this.btn_Them.Location = new System.Drawing.Point(54, 173);
			this.btn_Them.Name = "btn_Them";
			this.btn_Them.Size = new System.Drawing.Size(75, 23);
			this.btn_Them.TabIndex = 70;
			this.btn_Them.Text = "Them";
			this.btn_Them.UseVisualStyleBackColor = true;
			this.btn_Them.Click += new System.EventHandler(this.btn_Them_Click);
			// 
			// btn_Thoat
			// 
			this.btn_Thoat.Location = new System.Drawing.Point(466, 174);
			this.btn_Thoat.Name = "btn_Thoat";
			this.btn_Thoat.Size = new System.Drawing.Size(75, 23);
			this.btn_Thoat.TabIndex = 73;
			this.btn_Thoat.Text = "Thoát";
			this.btn_Thoat.UseVisualStyleBackColor = true;
			this.btn_Thoat.Click += new System.EventHandler(this.btn_Thoat_Click);
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thêmToolStripMenuItem,
            this.sửaToolStripMenuItem,
            this.xoáToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(113, 76);
			// 
			// thêmToolStripMenuItem
			// 
			this.thêmToolStripMenuItem.Name = "thêmToolStripMenuItem";
			this.thêmToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
			this.thêmToolStripMenuItem.Text = "Thêm";
			this.thêmToolStripMenuItem.Click += new System.EventHandler(this.btn_Them_Click);
			// 
			// sửaToolStripMenuItem
			// 
			this.sửaToolStripMenuItem.Name = "sửaToolStripMenuItem";
			this.sửaToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
			this.sửaToolStripMenuItem.Text = "Sửa";
			this.sửaToolStripMenuItem.Click += new System.EventHandler(this.btn_Sua_Click);
			// 
			// xoáToolStripMenuItem
			// 
			this.xoáToolStripMenuItem.Name = "xoáToolStripMenuItem";
			this.xoáToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
			this.xoáToolStripMenuItem.Text = "Xoá";
			this.xoáToolStripMenuItem.Click += new System.EventHandler(this.btn_Xoa_Click);
			// 
			// frm_DanhMucHang
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(846, 448);
			this.ContextMenuStrip = this.contextMenuStrip1;
			this.Controls.Add(this.btn_Thoat);
			this.Controls.Add(this.btn_Xoa);
			this.Controls.Add(this.btn_Sua);
			this.Controls.Add(this.btn_Them);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.cb_DonViTinh);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.cb_NhaCungCap);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txt_TenHang);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txt_MaHang);
			this.Controls.Add(this.label1);
			this.Name = "frm_DanhMucHang";
			this.Text = "frm_DanhMucHang";
			this.Load += new System.EventHandler(this.frm_DanhMucHang_Load);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txt_MaHang;
		private System.Windows.Forms.TextBox txt_TenHang;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cb_NhaCungCap;
		private System.Windows.Forms.ComboBox cb_DonViTinh;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Button btn_Xoa;
		private System.Windows.Forms.Button btn_Sua;
		private System.Windows.Forms.Button btn_Them;
		private System.Windows.Forms.Button btn_Thoat;
		private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem thêmToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem sửaToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem xoáToolStripMenuItem;
	}
}